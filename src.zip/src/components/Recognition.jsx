import React from 'react'

const Recognition = () => {
  return (
    <div>
      <h1>Recognition</h1>
    </div>
  )
}

export default Recognition
