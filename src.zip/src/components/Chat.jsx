import React from 'react'

const Chat = () => {
  return (
    <div>
      <h1>chat</h1>
    </div>
  )
}

export default Chat
