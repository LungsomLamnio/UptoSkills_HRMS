import React from 'react'

const Employees = () => {
  return (
    <div>
      <h1>Employees</h1>
    </div>
  )
}

export default Employees
