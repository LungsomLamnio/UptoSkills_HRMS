import React from 'react'

const Setting = () => {
  return (
    <div>
      <h1>Setting</h1>
    </div>
  )
}

export default Setting
